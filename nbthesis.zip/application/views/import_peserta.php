<style>
	.row {
		display: flex;
		justify-content: center;
		align-items: center;
	}
</style>

<div class="container">
	<div class="bg-blue-100 h-full w-full">
		ok
	</div>
</div>
